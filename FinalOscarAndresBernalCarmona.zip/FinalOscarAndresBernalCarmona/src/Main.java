// quitar ciudad de ataque y tipo//
public class Main {

}
