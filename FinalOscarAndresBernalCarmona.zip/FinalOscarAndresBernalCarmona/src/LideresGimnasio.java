import java.util.Scanner;
import java.util.Arrays;

public class LideresGimnasio {
	String nombre,clase,ciudad;
	String dulcesFavoritos[];
	String pokemon[];
	long fuerza;

	Scanner sc= new Scanner (System.in);

	public String liderNombre() {
		System.out.println("ingrese el nombre del lider de gimnasio");
		nombre = sc.nextLine();
		return nombre;
	}
	public void liderClase() {
		System.out.println("escriba la clase del lider");
		clase=sc.nextLine();
	}
	public void liderDulces() {
		System.out.println("ingrese el numero de dulces que le gustan al lider");
		int x = sc.nextInt();
		dulcesFavoritos= new String[x];
		System.out.println("ingrese el nombre de los dulces que le gustan al lider");
		for(int i=0;i<dulcesFavoritos.length;i++) {
			dulcesFavoritos[i]=sc.nextLine();
		}
	}
	public void pokemonesLider() {
		System.out.println("diga cuales pokemones componen el equipo del lider (solo 3 pokemones)");
		Pokemon pokemon = new Pokemon[3];
	}
}
