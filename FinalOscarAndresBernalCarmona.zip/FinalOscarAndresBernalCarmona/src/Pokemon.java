import java.util.Scanner;
import java.util.Arrays;
public class Pokemon {
	int id;
	String nombre;
	long ataque,defensa;
	String tipos[];
	String debilidades[];
	String movimientos[];
	Scanner sc= new Scanner (System.in);

	public void determIdentificacion() {
		System.out.println("ingrese el numero de identificacion del pokemon en cuestion");
		id = sc.nextInt();
	}
	public void determNombre() {
		System.out.println("Ingrese el nombre del pokemon en cuestion");
		nombre = sc.nextLine();
	}
	public void determTipos() {
		System.out.println("ingrese la cantidad de tipos de da�o del pokemon en cuestion");
		int x = sc.nextInt();
		System.out.println("diga el(o los tipos) de da�o del pokemon en cuestion");
		tipos= new String[x];
		for(int i=0;i<tipos.length;i++) {
			tipos[i]=sc.nextLine();
		}
	}
	public void determDebilidades() {
		System.out.println("ingrese el numero de vulnerabilidades del pokemon en cuestion");
		int y = sc.nextInt();
		System.out.println("ingrese las vulnerabilidades del pokemon en cuestion");
		debilidades= new String[y];
		for(int i=0;i<debilidades.length;i++) {
			debilidades[i]=sc.nextLine();
		}
	}
	public void determAtaque() {
		System.out.println("ingrese el valor de da�o de ataque del pokemon en cuestion");
		ataque = sc.nextLong();
	}
	public void determDefensa() {
		System.out.println("ingrese el valor de defensa del pokemon en cuestion");
		defensa = sc.nextLong();
	}
	public void determMovimientos() {
		System.out.println("ingrese la cantidad de movimientos aprendidos por el pokemon en cuestion");
		int z = sc.nextInt();
		System.out.println("ingrese los moviminetos aprendidos por el pokemon en cuestion");
		String[] movimientos = new String[z];
		for(int i=0;i<movimientos.length;i++) {
			movimientos[i]=sc.nextLine();
		}
	}
	public void mostrarDatos() {
		System.out.println(id+nombre+ataque+defensa);
		System.out.println(Arrays.toString(tipos));
		System.out.println(Arrays.toString(debilidades));
		System.out.println(Arrays.toString(movimientos));
	}
}
